<?php
namespace app\common\logic;

use app\common\basics\Logic;

class RefundLogic extends Logic
{
    /**
     * 余额退款
     */
    public static function balanceRefund()
    {

    }
}

<?php
namespace app\common\enum;
class ActivityAreaEnum
{

    const STATUS_OPEN = 1;
    const STATUS_CLOSE = 0;

}
<?php
namespace app\common\model;

use app\common\basics\Models;

/**
 * 充值规则模型
 * Class RechargeRule
 * @package app\common\model
 */
class RechargeRule extends Models
{

}

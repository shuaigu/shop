<?php
namespace  app\common\model;

use app\common\basics\Models;

class Session extends Models
{

}
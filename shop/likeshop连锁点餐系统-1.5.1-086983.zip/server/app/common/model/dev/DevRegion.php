<?php
namespace app\common\model\dev;

use app\common\basics\Models;

class DevRegion extends Models
{

}
<?php


namespace app\common\model\shop;


use app\common\basics\Models;

class ShopBank extends Models
{

}
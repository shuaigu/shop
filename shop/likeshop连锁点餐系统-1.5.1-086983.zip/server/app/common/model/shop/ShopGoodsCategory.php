<?php
namespace app\common\model\shop;

use app\common\basics\Models;

class ShopGoodsCategory extends Models
{
  
}


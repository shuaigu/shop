<?php
// +----------------------------------------------------------------------
// | LikeShop100%开源免费商用电商系统
// +----------------------------------------------------------------------
// | 欢迎阅读学习系统程序代码，建议反馈是我们前进的动力
// | 开源版本可自由商用，可去除界面版权logo
// | 商业版本务必购买商业授权，以免引起法律纠纷
// | 禁止对系统程序代码以任何目的，任何形式的再发布
// | Gitee下载：https://gitee.com/likeshop_gitee/likeshop
// | 访问官网：https://www.likemarket.net
// | 访问社区：https://home.likemarket.net
// | 访问手册：http://doc.likemarket.net
// | 微信公众号：好象科技
// | 好象科技开发团队 版权所有 拥有最终解释权
// +----------------------------------------------------------------------

// | Author: LikeShopTeam
// +----------------------------------------------------------------------

namespace app\api\validate;

use app\common\basics\Validate;
use app\common\enum\NoticeEnum;
use app\common\logic\SmsLogic;
use app\common\model\user\User;

/**
 * 绑定用户手机号验证器
 * Class ChangeMobileValidate
 * @package app\api\validate
 */
class BindMobileValidate extends Validate
{
    protected $rule = [
        'mobile' => 'require|mobile|checkMobile',
        'code'      => 'require|checkCode'
    ];

    protected $message = [
        'mobile.require' => '参数缺失',
        'mobile.mobile' => '请填写正确的手机号',
        'code.require'      => '请输入验证码',
    ];

    //检查新手机号是否已存在
    protected function checkMobile($value, $rule, $data)
    {
        $user = User::where([
            ['mobile', '=', $value],
            ['id', '<>', $data['user_id']]
        ])->findOrEmpty();

        if (!$user->isEmpty()) {
            return '此手机号已被使用';
        }
        return true;
    }


    /**
     * @notes 验证验证码
     * @param $value
     * @param $rule
     * @param $data
     * @return array|string|void
     * @author cjhao
     * @date 2023/10/9 11:21
     */
    protected function checkCode($value, $rule, $data)
    {
        $res = SmsLogic::check(NoticeEnum::BINDMOBILE_NOTICE, $data['mobile'], $value);
        if (false === $res) {
            return SmsLogic::getError();
        }
        return true;

    }
}
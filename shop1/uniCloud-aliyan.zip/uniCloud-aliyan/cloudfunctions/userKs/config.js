// 快手配置
module.exports = {
	app_id_ks: 'ks684828620418942246',
	app_secret_ks: 'QCMyq4hpRVD4a3xlwFYU8A'
}
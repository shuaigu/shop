// config.js
const config = {
	notifyUrl: 'https://fc-mp-4f80f767-c485-40d3-b143-9134b266a903.next.bspapp.com/wxpay-notify',
	appid: 'wxf7ee79349bd957b8',
	mch_id: '1545803671',
	partner_key: 'lishuai4323811lishuai4323811lish'
}

module.exports = config
// 抖音配置
module.exports = {
	app_id_dy: 'tt263f5082b90a75da01',
	app_secret_dy: '4c8594e021adce3bda126c2cdf50159515402a91',
	sandbox:false
}
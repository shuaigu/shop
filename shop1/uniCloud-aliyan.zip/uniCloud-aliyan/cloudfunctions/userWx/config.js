// 快手配置
module.exports = {
	app_id_wx: 'wxf7ee79349bd957b8',
	app_secret_wx: '725f689abdc2c51a36330a813c1b7215'
}